import React, { useState } from 'react';
import { BarChart3, TrendingUp, Users, Clock, Calendar, Download } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Legend, PieChart, Pie, Cell, LineChart, Line } from 'recharts';

const Analytics: React.FC = () => {
  const [timeRange, setTimeRange] = useState('7days');

  const salesData = [
    { day: 'Mon', sales: 245, revenue: 1234, customers: 89 },
    { day: 'Tue', sales: 189, revenue: 987, customers: 67 },
    { day: 'Wed', sales: 312, revenue: 1567, customers: 112 },
    { day: 'Thu', sales: 287, revenue: 1443, customers: 98 },
    { day: 'Fri', sales: 398, revenue: 1987, customers: 143 },
    { day: 'Sat', sales: 456, revenue: 2234, customers: 167 },
    { day: 'Sun', sales: 378, revenue: 1876, customers: 134 },
  ];

  const categoryData = [
    { name: 'Beverages', value: 32, color: '#3B82F6' },
    { name: 'Snacks', value: 24, color: '#10B981' },
    { name: 'Dairy', value: 18, color: '#F59E0B' },
    { name: 'Frozen', value: 14, color: '#EF4444' },
    { name: 'Bakery', value: 12, color: '#8B5CF6' },
  ];

  const hourlyTraffic = [
    { hour: '6AM', traffic: 12 },
    { hour: '8AM', traffic: 45 },
    { hour: '10AM', traffic: 67 },
    { hour: '12PM', traffic: 89 },
    { hour: '2PM', traffic: 76 },
    { hour: '4PM', traffic: 54 },
    { hour: '6PM', traffic: 93 },
    { hour: '8PM', traffic: 67 },
    { hour: '10PM', traffic: 23 },
  ];

  const topProducts = [
    { name: 'Coca Cola 500ml', sales: 145, revenue: 433.55, change: 12.5 },
    { name: 'Lay\'s Potato Chips', sales: 89, revenue: 310.61, change: -3.2 },
    { name: 'Wonder Bread', sales: 76, revenue: 212.04, change: 8.7 },
    { name: 'Fresh Milk 1L', sales: 67, revenue: 334.33, change: 15.3 },
    { name: 'Frozen Pizza', sales: 54, revenue: 485.46, change: -1.8 },
  ];

  const timeRanges = [
    { value: '7days', label: 'Last 7 Days' },
    { value: '30days', label: 'Last 30 Days' },
    { value: '90days', label: 'Last 90 Days' },
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Analytics & Reports</h1>
          <p className="text-gray-400 mt-1">Comprehensive insights and performance metrics</p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {timeRanges.map(range => (
              <option key={range.value} value={range.value}>
                {range.label}
              </option>
            ))}
          </select>

          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors">
            <Download className="w-4 h-4" />
            Export Report
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">$12,847</p>
              <p className="text-sm text-gray-400">Total Revenue</p>
              <div className="flex items-center gap-1 mt-1">
                <TrendingUp className="w-3 h-3 text-green-400" />
                <span className="text-xs text-green-400">+8.2%</span>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">810</p>
              <p className="text-sm text-gray-400">Total Customers</p>
              <div className="flex items-center gap-1 mt-1">
                <TrendingUp className="w-3 h-3 text-green-400" />
                <span className="text-xs text-green-400">+12.5%</span>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-600 rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">4.2 min</p>
              <p className="text-sm text-gray-400">Avg. Checkout Time</p>
              <div className="flex items-center gap-1 mt-1">
                <TrendingUp className="w-3 h-3 text-red-400 rotate-180" />
                <span className="text-xs text-red-400">-15.3%</span>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">95.7%</p>
              <p className="text-sm text-gray-400">Stock Availability</p>
              <div className="flex items-center gap-1 mt-1">
                <TrendingUp className="w-3 h-3 text-green-400" />
                <span className="text-xs text-green-400">+2.1%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sales Trend */}
        <div className="bg-gray-800 rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-4">Sales Trend</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="day" stroke="#9CA3AF" fontSize={12} />
                <YAxis stroke="#9CA3AF" fontSize={12} />
                <Legend />
                <Bar dataKey="sales" fill="#3B82F6" name="Sales Count" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Distribution */}
        <div className="bg-gray-800 rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-4">Sales by Category</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={120}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Additional Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Hourly Traffic */}
        <div className="bg-gray-800 rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-4">Hourly Traffic</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={hourlyTraffic}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="hour" stroke="#9CA3AF" fontSize={10} />
                <YAxis stroke="#9CA3AF" fontSize={10} />
                <Line 
                  type="monotone" 
                  dataKey="traffic" 
                  stroke="#10B981" 
                  strokeWidth={2}
                  dot={{ fill: '#10B981', strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top Products */}
        <div className="lg:col-span-2 bg-gray-800 rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-4">Top Performing Products</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="text-left py-2 text-gray-400 text-sm font-medium">Product</th>
                  <th className="text-left py-2 text-gray-400 text-sm font-medium">Sales</th>
                  <th className="text-left py-2 text-gray-400 text-sm font-medium">Revenue</th>
                  <th className="text-left py-2 text-gray-400 text-sm font-medium">Change</th>
                </tr>
              </thead>
              <tbody>
                {topProducts.map((product, index) => (
                  <tr key={index} className="border-b border-gray-700/50">
                    <td className="py-3">
                      <div className="font-medium text-white">{product.name}</div>
                    </td>
                    <td className="py-3 text-gray-300">{product.sales}</td>
                    <td className="py-3 text-gray-300">${product.revenue.toFixed(2)}</td>
                    <td className="py-3">
                      <span className={`flex items-center gap-1 ${
                        product.change > 0 ? 'text-green-400' : 'text-red-400'
                      }`}>
                        <TrendingUp className={`w-3 h-3 ${product.change < 0 ? 'rotate-180' : ''}`} />
                        {Math.abs(product.change)}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Revenue Chart */}
      <div className="bg-gray-800 rounded-xl p-6">
        <h2 className="text-xl font-semibold mb-4">Revenue & Customer Trends</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="day" stroke="#9CA3AF" fontSize={12} />
              <YAxis yAxisId="left" stroke="#9CA3AF" fontSize={12} />
              <YAxis yAxisId="right" orientation="right" stroke="#9CA3AF" fontSize={12} />
              <Legend />
              <Line 
                yAxisId="left"
                type="monotone" 
                dataKey="revenue" 
                stroke="#3B82F6" 
                strokeWidth={3}
                name="Revenue ($)"
                dot={{ fill: '#3B82F6', strokeWidth: 2, r: 5 }}
              />
              <Line 
                yAxisId="right"
                type="monotone" 
                dataKey="customers" 
                stroke="#10B981" 
                strokeWidth={3}
                name="Customers"
                dot={{ fill: '#10B981', strokeWidth: 2, r: 5 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Analytics;