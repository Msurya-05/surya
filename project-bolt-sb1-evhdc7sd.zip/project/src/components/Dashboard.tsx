import React from 'react';
import { 
  Package, 
  AlertTriangle, 
  TrendingUp, 
  Eye,
  ShoppingCart,
  Clock,
  CheckCircle,
  XCircle
} from 'lucide-react';
import MetricCard from './MetricCard';
import RecentAlerts from './RecentAlerts';
import StockLevelChart from './StockLevelChart';
import LiveCameraFeed from './LiveCameraFeed';

const Dashboard: React.FC = () => {
  const metrics = [
    {
      title: 'Total Products',
      value: '2,847',
      change: '+12',
      trend: 'up' as const,
      icon: Package,
      color: 'blue'
    },
    {
      title: 'Low Stock Alerts',
      value: '23',
      change: '-5',
      trend: 'down' as const,
      icon: AlertTriangle,
      color: 'orange'
    },
    {
      title: 'Predicted Demand',
      value: '+18%',
      change: '+3%',
      trend: 'up' as const,
      icon: TrendingUp,
      color: 'green'
    },
    {
      title: 'Active Cameras',
      value: '12/12',
      change: '100%',
      trend: 'up' as const,
      icon: Eye,
      color: 'purple'
    }
  ];

  const recentActivity = [
    {
      id: 1,
      type: 'stock_low',
      message: 'Coca Cola 500ml - Stock below threshold',
      timestamp: '2 minutes ago',
      severity: 'high',
      icon: AlertTriangle
    },
    {
      id: 2,
      type: 'misplaced',
      message: 'Snickers Bar detected in wrong aisle',
      timestamp: '5 minutes ago',
      severity: 'medium',
      icon: Package
    },
    {
      id: 3,
      type: 'restock',
      message: 'Bread section restocked successfully',
      timestamp: '12 minutes ago',
      severity: 'low',
      icon: CheckCircle
    },
    {
      id: 4,
      type: 'demand_spike',
      message: 'Demand spike predicted for Energy Drinks',
      timestamp: '18 minutes ago',
      severity: 'medium',
      icon: TrendingUp
    }
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">AI Inventory Dashboard</h1>
          <p className="text-gray-400 mt-1">Real-time monitoring and intelligent forecasting</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="px-4 py-2 bg-green-600 text-white rounded-lg flex items-center gap-2">
            <div className="w-2 h-2 bg-green-200 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium">System Active</span>
          </div>
          <div className="text-sm text-gray-400">
            Last update: {new Date().toLocaleTimeString()}
          </div>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => (
          <MetricCard key={index} {...metric} />
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Live Camera Feeds */}
        <div className="lg:col-span-2">
          <div className="bg-gray-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">Live Camera Monitoring</h2>
              <div className="flex items-center gap-2 text-green-400">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-sm">Live</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <LiveCameraFeed cameraId="CAM-01" location="Aisle 1 - Beverages" />
              <LiveCameraFeed cameraId="CAM-03" location="Aisle 3 - Snacks" />
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-gray-800 rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
          <div className="space-y-4">
            {recentActivity.map((activity) => {
              const IconComponent = activity.icon;
              const severityColors = {
                high: 'text-red-400 bg-red-400/10',
                medium: 'text-orange-400 bg-orange-400/10',
                low: 'text-green-400 bg-green-400/10'
              };

              return (
                <div key={activity.id} className="flex items-start gap-3 p-3 bg-gray-700 rounded-lg">
                  <div className={`p-2 rounded-lg ${severityColors[activity.severity]}`}>
                    <IconComponent className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white">{activity.message}</p>
                    <p className="text-xs text-gray-400 mt-1">{activity.timestamp}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Stock Level Chart */}
      <div className="bg-gray-800 rounded-xl p-6">
        <h2 className="text-xl font-semibold mb-4">Stock Level Trends</h2>
        <StockLevelChart />
      </div>
    </div>
  );
};

export default Dashboard;