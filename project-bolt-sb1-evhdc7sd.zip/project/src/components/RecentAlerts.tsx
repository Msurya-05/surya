import React from 'react';
import { AlertTriangle, Package, CheckCircle, TrendingUp } from 'lucide-react';

const RecentAlerts: React.FC = () => {
  const alerts = [
    {
      id: 1,
      type: 'stock_low',
      message: 'Coca Cola 500ml - Stock below threshold',
      timestamp: '2 minutes ago',
      severity: 'high',
      icon: AlertTriangle
    },
    {
      id: 2,
      type: 'misplaced',
      message: 'Snickers Bar detected in wrong aisle',
      timestamp: '5 minutes ago',
      severity: 'medium',
      icon: Package
    },
    {
      id: 3,
      type: 'restock',
      message: 'Bread section restocked successfully',
      timestamp: '12 minutes ago',
      severity: 'low',
      icon: CheckCircle
    },
    {
      id: 4,
      type: 'demand_spike',
      message: 'Demand spike predicted for Energy Drinks',
      timestamp: '18 minutes ago',
      severity: 'medium',
      icon: TrendingUp
    }
  ];

  const severityColors = {
    high: 'text-red-400 bg-red-400/10',
    medium: 'text-orange-400 bg-orange-400/10',
    low: 'text-green-400 bg-green-400/10'
  };

  return (
    <div className="space-y-4">
      {alerts.map((alert) => {
        const IconComponent = alert.icon;
        
        return (
          <div key={alert.id} className="flex items-start gap-3 p-3 bg-gray-700 rounded-lg">
            <div className={`p-2 rounded-lg ${severityColors[alert.severity]}`}>
              <IconComponent className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white">{alert.message}</p>
              <p className="text-xs text-gray-400 mt-1">{alert.timestamp}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default RecentAlerts;