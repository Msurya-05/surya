import React, { useState } from 'react';
import { TrendingUp, Calendar, BarChart3, Target, Brain } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Legend, BarChart, Bar } from 'recharts';

const Forecasting: React.FC = () => {
  const [selectedProduct, setSelectedProduct] = useState('coca-cola');
  const [timeRange, setTimeRange] = useState('7days');

  const demandData = [
    { date: '2025-01-09', actual: 45, predicted: 47, confidence: 0.92 },
    { date: '2025-01-10', actual: 52, predicted: 51, confidence: 0.89 },
    { date: '2025-01-11', actual: 38, predicted: 41, confidence: 0.94 },
    { date: '2025-01-12', actual: 67, predicted: 63, confidence: 0.88 },
    { date: '2025-01-13', actual: null, predicted: 58, confidence: 0.91 },
    { date: '2025-01-14', actual: null, predicted: 62, confidence: 0.87 },
    { date: '2025-01-15', actual: null, predicted: 55, confidence: 0.89 },
  ];

  const categoryForecast = [
    { category: 'Beverages', currentWeek: 420, nextWeek: 468, growth: 11.4 },
    { category: 'Snacks', currentWeek: 285, nextWeek: 312, growth: 9.5 },
    { category: 'Dairy', currentWeek: 190, nextWeek: 198, growth: 4.2 },
    { category: 'Frozen', currentWeek: 156, nextWeek: 172, growth: 10.3 },
    { category: 'Bakery', currentWeek: 134, nextWeek: 125, growth: -6.7 },
  ];

  const products = [
    { value: 'coca-cola', label: 'Coca Cola 500ml' },
    { value: 'lays-chips', label: 'Lay\'s Potato Chips' },
    { value: 'fresh-milk', label: 'Fresh Milk 1L' },
    { value: 'wonder-bread', label: 'Wonder Bread' },
  ];

  const timeRanges = [
    { value: '7days', label: '7 Days' },
    { value: '30days', label: '30 Days' },
    { value: '90days', label: '90 Days' },
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Demand Forecasting</h1>
          <p className="text-gray-400 mt-1">AI-powered demand prediction and trend analysis</p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <select
            value={selectedProduct}
            onChange={(e) => setSelectedProduct(e.target.value)}
            className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {products.map(product => (
              <option key={product.value} value={product.value}>
                {product.label}
              </option>
            ))}
          </select>

          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {timeRanges.map(range => (
              <option key={range.value} value={range.value}>
                {range.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">92.4%</p>
              <p className="text-sm text-gray-400">Model Accuracy</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">+8.7%</p>
              <p className="text-sm text-gray-400">Expected Growth</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-600 rounded-lg flex items-center justify-center">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">387</p>
              <p className="text-sm text-gray-400">Units Next Week</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">3</p>
              <p className="text-sm text-gray-400">Days to Restock</p>
            </div>
          </div>
        </div>
      </div>

      {/* Demand Prediction Chart */}
      <div className="bg-gray-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold">Demand Prediction Timeline</h2>
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-blue-500 rounded"></div>
              <span>Actual Sales</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded"></div>
              <span>Predicted Demand</span>
            </div>
          </div>
        </div>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={demandData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis 
                dataKey="date" 
                stroke="#9CA3AF"
                fontSize={12}
                tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
              />
              <YAxis 
                stroke="#9CA3AF"
                fontSize={12}
                label={{ value: 'Units Sold', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#9CA3AF' } }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="actual" 
                stroke="#3B82F6" 
                strokeWidth={3}
                name="Actual Sales"
                dot={{ fill: '#3B82F6', strokeWidth: 2, r: 5 }}
                connectNulls={false}
              />
              <Line 
                type="monotone" 
                dataKey="predicted" 
                stroke="#10B981" 
                strokeWidth={3}
                strokeDasharray="5 5"
                name="Predicted Demand"
                dot={{ fill: '#10B981', strokeWidth: 2, r: 5 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Category Forecast */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800 rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-6">Category Growth Forecast</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryForecast}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="category" 
                  stroke="#9CA3AF"
                  fontSize={12}
                />
                <YAxis 
                  stroke="#9CA3AF"
                  fontSize={12}
                  label={{ value: 'Units', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#9CA3AF' } }}
                />
                <Legend />
                <Bar 
                  dataKey="currentWeek" 
                  fill="#6B7280" 
                  name="Current Week"
                  radius={[4, 4, 0, 0]}
                />
                <Bar 
                  dataKey="nextWeek" 
                  fill="#3B82F6" 
                  name="Next Week Forecast"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-6">Forecast Insights</h2>
          <div className="space-y-4">
            {categoryForecast.map((category, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                <div>
                  <h3 className="font-medium text-white">{category.category}</h3>
                  <p className="text-sm text-gray-400">
                    {category.currentWeek} → {category.nextWeek} units
                  </p>
                </div>
                <div className={`flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium ${
                  category.growth > 0 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-red-100 text-red-800'
                }`}>
                  {category.growth > 0 ? (
                    <TrendingUp className="w-4 h-4" />
                  ) : (
                    <TrendingUp className="w-4 h-4 rotate-180" />
                  )}
                  {Math.abs(category.growth)}%
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 p-4 bg-blue-600/10 border border-blue-600/20 rounded-lg">
            <h3 className="font-medium text-blue-400 mb-2">AI Recommendation</h3>
            <p className="text-sm text-gray-300">
              Based on seasonal trends and recent sales data, consider increasing beverage inventory by 15% 
              for the upcoming weekend. High confidence prediction suggests strong demand growth.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Forecasting;