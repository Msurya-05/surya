import React, { useState } from 'react';
import { Package, Search, Filter, AlertTriangle, TrendingUp, TrendingDown, BarChart } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  category: string;
  currentStock: number;
  minThreshold: number;
  maxCapacity: number;
  lastRestocked: string;
  predicted7Days: number;
  status: 'in_stock' | 'low_stock' | 'out_of_stock' | 'overstock';
  price: number;
}

const InventoryManagement: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');

  const products: Product[] = [
    {
      id: 'P001',
      name: 'Coca Cola 500ml',
      category: 'Beverages',
      currentStock: 45,
      minThreshold: 20,
      maxCapacity: 200,
      lastRestocked: '2025-01-08',
      predicted7Days: 65,
      status: 'in_stock',
      price: 2.99
    },
    {
      id: 'P002',
      name: 'Lay\'s Potato Chips',
      category: 'Snacks',
      currentStock: 8,
      minThreshold: 15,
      maxCapacity: 150,
      lastRestocked: '2025-01-07',
      predicted7Days: 25,
      status: 'low_stock',
      price: 3.49
    },
    {
      id: 'P003',
      name: 'Fresh Milk 1L',
      category: 'Dairy',
      currentStock: 0,
      minThreshold: 10,
      maxCapacity: 100,
      lastRestocked: '2025-01-06',
      predicted7Days: 35,
      status: 'out_of_stock',
      price: 4.99
    },
    {
      id: 'P004',
      name: 'Wonder Bread',
      category: 'Bakery',
      currentStock: 85,
      minThreshold: 25,
      maxCapacity: 80,
      lastRestocked: '2025-01-08',
      predicted7Days: 40,
      status: 'overstock',
      price: 2.79
    },
    {
      id: 'P005',
      name: 'Frozen Pizza',
      category: 'Frozen',
      currentStock: 32,
      minThreshold: 15,
      maxCapacity: 120,
      lastRestocked: '2025-01-07',
      predicted7Days: 28,
      status: 'in_stock',
      price: 8.99
    }
  ];

  const categories = ['all', ...Array.from(new Set(products.map(p => p.category)))];
  const statuses = [
    { value: 'all', label: 'All Status' },
    { value: 'in_stock', label: 'In Stock' },
    { value: 'low_stock', label: 'Low Stock' },
    { value: 'out_of_stock', label: 'Out of Stock' },
    { value: 'overstock', label: 'Overstock' }
  ];

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    const matchesStatus = selectedStatus === 'all' || product.status === selectedStatus;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'in_stock': return 'bg-green-100 text-green-800';
      case 'low_stock': return 'bg-orange-100 text-orange-800';
      case 'out_of_stock': return 'bg-red-100 text-red-800';
      case 'overstock': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStockPercentage = (current: number, max: number) => {
    return Math.min((current / max) * 100, 100);
  };

  const getPredictionTrend = (current: number, predicted: number) => {
    return predicted > current ? 'up' : 'down';
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Inventory Management</h1>
          <p className="text-gray-400 mt-1">Monitor stock levels and manage inventory with AI insights</p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {categories.map(category => (
              <option key={category} value={category}>
                {category === 'all' ? 'All Categories' : category}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {statuses.map(status => (
              <option key={status.value} value={status.value}>
                {status.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{products.length}</p>
              <p className="text-sm text-gray-400">Total Products</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{products.filter(p => p.status === 'low_stock' || p.status === 'out_of_stock').length}</p>
              <p className="text-sm text-gray-400">Critical Items</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">
                ${products.reduce((sum, p) => sum + (p.currentStock * p.price), 0).toLocaleString()}
              </p>
              <p className="text-sm text-gray-400">Total Value</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center">
              <BarChart className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">
                {Math.round(products.reduce((sum, p) => sum + getStockPercentage(p.currentStock, p.maxCapacity), 0) / products.length)}%
              </p>
              <p className="text-sm text-gray-400">Avg Fill Rate</p>
            </div>
          </div>
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-gray-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Product</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Category</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Current Stock</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">7-Day Prediction</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Last Restocked</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {filteredProducts.map((product) => {
                const stockPercentage = getStockPercentage(product.currentStock, product.maxCapacity);
                const predictionTrend = getPredictionTrend(product.currentStock, product.predicted7Days);
                
                return (
                  <tr key={product.id} className="hover:bg-gray-700">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="font-medium text-white">{product.name}</div>
                        <div className="text-sm text-gray-400">{product.id}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-300">
                      {product.category}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-3">
                        <div className="flex-1">
                          <div className="text-sm font-medium text-white">
                            {product.currentStock} / {product.maxCapacity}
                          </div>
                          <div className="w-full bg-gray-600 rounded-full h-2 mt-1">
                            <div 
                              className={`h-2 rounded-full ${
                                stockPercentage < 25 ? 'bg-red-500' :
                                stockPercentage < 50 ? 'bg-orange-500' :
                                stockPercentage > 85 ? 'bg-blue-500' : 'bg-green-500'
                              }`}
                              style={{ width: `${stockPercentage}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(product.status)}`}>
                        {product.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <span className="text-white font-medium">{product.predicted7Days}</span>
                        {predictionTrend === 'up' ? (
                          <TrendingUp className="w-4 h-4 text-green-400" />
                        ) : (
                          <TrendingDown className="w-4 h-4 text-red-400" />
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                      {new Date(product.lastRestocked).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <button className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-xs font-medium transition-colors">
                        Restock
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default InventoryManagement;