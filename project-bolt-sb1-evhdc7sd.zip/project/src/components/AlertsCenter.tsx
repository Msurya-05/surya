import React, { useState } from 'react';
import { 
  AlertTriangle, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Filter,
  Bell,
  Package,
  TrendingDown,
  MapPin
} from 'lucide-react';

interface Alert {
  id: string;
  type: 'low_stock' | 'out_of_stock' | 'misplaced' | 'demand_spike' | 'system';
  severity: 'high' | 'medium' | 'low';
  title: string;
  description: string;
  location: string;
  timestamp: string;
  status: 'active' | 'acknowledged' | 'resolved';
  product?: string;
  currentStock?: number;
  threshold?: number;
}

const AlertsCenter: React.FC = () => {
  const [filterSeverity, setFilterSeverity] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');

  const alerts: Alert[] = [
    {
      id: 'ALT001',
      type: 'out_of_stock',
      severity: 'high',
      title: 'Fresh Milk 1L - Out of Stock',
      description: 'Product completely out of stock. Last sale recorded 2 hours ago.',
      location: 'Aisle 2 - Dairy Section',
      timestamp: '2025-01-09T10:15:00Z',
      status: 'active',
      product: 'Fresh Milk 1L',
      currentStock: 0,
      threshold: 10
    },
    {
      id: 'ALT002',
      type: 'low_stock',
      severity: 'medium',
      title: 'Lay\'s Potato Chips - Low Stock',
      description: 'Current stock below minimum threshold. Restock recommended.',
      location: 'Aisle 3 - Snacks',
      timestamp: '2025-01-09T09:30:00Z',
      status: 'acknowledged',
      product: 'Lay\'s Potato Chips',
      currentStock: 8,
      threshold: 15
    },
    {
      id: 'ALT003',
      type: 'misplaced',
      severity: 'medium',
      title: 'Snickers Bar - Wrong Location',
      description: 'Product detected in Beverages aisle instead of Confectionery section.',
      location: 'Aisle 1 - Beverages (Should be Aisle 3)',
      timestamp: '2025-01-09T08:45:00Z',
      status: 'active',
      product: 'Snickers Bar'
    },
    {
      id: 'ALT004',
      type: 'demand_spike',
      severity: 'low',
      title: 'Energy Drinks - Demand Spike Predicted',
      description: 'AI model predicts 40% increase in demand for next 3 days.',
      location: 'Aisle 1 - Beverages',
      timestamp: '2025-01-09T07:20:00Z',
      status: 'acknowledged',
      product: 'Energy Drinks'
    },
    {
      id: 'ALT005',
      type: 'system',
      severity: 'low',
      title: 'Camera CAM-05 - Maintenance Required',
      description: 'Scheduled maintenance window detected. Camera will be offline.',
      location: 'Aisle 5 - Personal Care',
      timestamp: '2025-01-09T06:00:00Z',
      status: 'resolved'
    }
  ];

  const severityOptions = [
    { value: 'all', label: 'All Severities' },
    { value: 'high', label: 'High' },
    { value: 'medium', label: 'Medium' },
    { value: 'low', label: 'Low' }
  ];

  const statusOptions = [
    { value: 'all', label: 'All Status' },
    { value: 'active', label: 'Active' },
    { value: 'acknowledged', label: 'Acknowledged' },
    { value: 'resolved', label: 'Resolved' }
  ];

  const typeOptions = [
    { value: 'all', label: 'All Types' },
    { value: 'low_stock', label: 'Low Stock' },
    { value: 'out_of_stock', label: 'Out of Stock' },
    { value: 'misplaced', label: 'Misplaced Items' },
    { value: 'demand_spike', label: 'Demand Spike' },
    { value: 'system', label: 'System Alerts' }
  ];

  const filteredAlerts = alerts.filter(alert => {
    return (filterSeverity === 'all' || alert.severity === filterSeverity) &&
           (filterStatus === 'all' || alert.status === filterStatus) &&
           (filterType === 'all' || alert.type === filterType);
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'text-red-400 bg-red-400/10 border-red-400/20';
      case 'medium': return 'text-orange-400 bg-orange-400/10 border-orange-400/20';
      case 'low': return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20';
      default: return 'text-gray-400 bg-gray-400/10 border-gray-400/20';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-red-100 text-red-800';
      case 'acknowledged': return 'bg-orange-100 text-orange-800';
      case 'resolved': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'low_stock':
      case 'out_of_stock':
        return Package;
      case 'misplaced':
        return MapPin;
      case 'demand_spike':
        return TrendingDown;
      case 'system':
        return Bell;
      default:
        return AlertTriangle;
    }
  };

  const getTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
      return `${diffInMinutes} minutes ago`;
    }
    return `${diffInHours} hours ago`;
  };

  const handleAcknowledge = (alertId: string) => {
    console.log(`Acknowledging alert ${alertId}`);
  };

  const handleResolve = (alertId: string) => {
    console.log(`Resolving alert ${alertId}`);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Alerts Center</h1>
          <p className="text-gray-400 mt-1">Monitor and manage system alerts and notifications</p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <select
            value={filterSeverity}
            onChange={(e) => setFilterSeverity(e.target.value)}
            className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {severityOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {statusOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>

          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {typeOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{alerts.filter(a => a.status === 'active').length}</p>
              <p className="text-sm text-gray-400">Active Alerts</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-600 rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{alerts.filter(a => a.severity === 'high' && a.status === 'active').length}</p>
              <p className="text-sm text-gray-400">Critical</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{alerts.filter(a => a.status === 'acknowledged').length}</p>
              <p className="text-sm text-gray-400">Acknowledged</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
              <XCircle className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{alerts.filter(a => a.status === 'resolved').length}</p>
              <p className="text-sm text-gray-400">Resolved</p>
            </div>
          </div>
        </div>
      </div>

      {/* Alerts List */}
      <div className="bg-gray-800 rounded-xl p-6">
        <h2 className="text-xl font-semibold mb-6">Recent Alerts</h2>
        <div className="space-y-4">
          {filteredAlerts.map((alert) => {
            const IconComponent = getTypeIcon(alert.type);
            
            return (
              <div key={alert.id} className={`border rounded-lg p-4 ${getSeverityColor(alert.severity)}`}>
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <IconComponent className="w-6 h-6" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-lg font-medium text-white">{alert.title}</h3>
                        <p className="text-gray-300 mt-1">{alert.description}</p>
                        <div className="flex items-center gap-4 mt-2 text-sm text-gray-400">
                          <span className="flex items-center gap-1">
                            <MapPin className="w-4 h-4" />
                            {alert.location}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {getTimeAgo(alert.timestamp)}
                          </span>
                        </div>
                        
                        {alert.product && (alert.currentStock !== undefined || alert.threshold !== undefined) && (
                          <div className="mt-3 p-3 bg-gray-700 rounded-lg">
                            <div className="flex items-center justify-between">
                              <span className="text-sm font-medium">Stock Info:</span>
                              <span className="text-sm">
                                Current: {alert.currentStock} | Threshold: {alert.threshold}
                              </span>
                            </div>
                          </div>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-3 ml-4">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(alert.status)}`}>
                          {alert.status}
                        </span>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize ${getSeverityColor(alert.severity)}`}>
                          {alert.severity}
                        </span>
                      </div>
                    </div>
                    
                    {alert.status === 'active' && (
                      <div className="flex gap-2 mt-4">
                        <button
                          onClick={() => handleAcknowledge(alert.id)}
                          className="px-3 py-1 bg-orange-600 hover:bg-orange-700 text-white text-sm rounded font-medium transition-colors"
                        >
                          Acknowledge
                        </button>
                        <button
                          onClick={() => handleResolve(alert.id)}
                          className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white text-sm rounded font-medium transition-colors"
                        >
                          Resolve
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default AlertsCenter;