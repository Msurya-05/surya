import React, { useState, useEffect } from 'react';
import { Video, Maximize2 } from 'lucide-react';

interface LiveCameraFeedProps {
  cameraId: string;
  location: string;
}

interface Detection {
  id: string;
  product: string;
  confidence: number;
  x: number;
  y: number;
  width: number;
  height: number;
}

const LiveCameraFeed: React.FC<LiveCameraFeedProps> = ({ cameraId, location }) => {
  const [detections, setDetections] = useState<Detection[]>([]);
  const [lastUpdate, setLastUpdate] = useState(new Date());

  // Simulate real-time product detections
  useEffect(() => {
    const interval = setInterval(() => {
      const mockDetections: Detection[] = [
        {
          id: '1',
          product: 'Coca Cola 500ml',
          confidence: 0.95,
          x: 20,
          y: 30,
          width: 60,
          height: 80
        },
        {
          id: '2',
          product: 'Pepsi 500ml',
          confidence: 0.88,
          x: 85,
          y: 25,
          width: 55,
          height: 85
        },
        {
          id: '3',
          product: 'Water Bottle',
          confidence: 0.92,
          x: 150,
          y: 40,
          width: 50,
          height: 90
        }
      ];

      setDetections(mockDetections);
      setLastUpdate(new Date());
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative bg-gray-900 rounded-lg overflow-hidden">
      <div className="aspect-video bg-gradient-to-br from-gray-700 to-gray-800 relative">
        {/* Simulated camera feed background */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-green-900/20"></div>
        
        {/* Detection overlays */}
        {detections.map((detection) => (
          <div
            key={detection.id}
            className="absolute border-2 border-green-400 bg-green-400/10"
            style={{
              left: `${detection.x}px`,
              top: `${detection.y}px`,
              width: `${detection.width}px`,
              height: `${detection.height}px`,
            }}
          >
            <div className="bg-green-400 text-black text-xs px-2 py-1 font-medium -mt-6">
              {detection.product} ({(detection.confidence * 100).toFixed(0)}%)
            </div>
          </div>
        ))}

        {/* Camera controls */}
        <div className="absolute top-2 right-2 flex gap-2">
          <button className="p-1 bg-black/50 text-white rounded hover:bg-black/70 transition-colors">
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>

        {/* Live indicator */}
        <div className="absolute top-2 left-2 flex items-center gap-2 bg-black/50 px-2 py-1 rounded">
          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
          <span className="text-white text-xs font-medium">LIVE</span>
        </div>

        {/* Detection count */}
        <div className="absolute bottom-2 left-2 bg-black/50 text-white px-2 py-1 rounded text-xs">
          {detections.length} items detected
        </div>
      </div>

      {/* Camera info */}
      <div className="p-3 bg-gray-800">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-medium text-white">{cameraId}</h3>
            <p className="text-sm text-gray-400">{location}</p>
          </div>
          <div className="flex items-center gap-2 text-green-400">
            <Video className="w-4 h-4" />
            <span className="text-xs">Online</span>
          </div>
        </div>
        <div className="text-xs text-gray-500 mt-2">
          Last update: {lastUpdate.toLocaleTimeString()}
        </div>
      </div>
    </div>
  );
};

export default LiveCameraFeed;