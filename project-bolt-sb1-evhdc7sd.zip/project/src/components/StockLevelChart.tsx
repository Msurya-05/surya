import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Legend } from 'recharts';

const StockLevelChart: React.FC = () => {
  const data = [
    { day: 'Mon', beverages: 89, snacks: 76, dairy: 92, frozen: 88 },
    { day: 'Tue', beverages: 82, snacks: 68, dairy: 89, frozen: 85 },
    { day: 'Wed', beverages: 75, snacks: 72, dairy: 87, frozen: 90 },
    { day: 'Thu', beverages: 68, snacks: 65, dairy: 85, frozen: 88 },
    { day: 'Fri', beverages: 92, snacks: 85, dairy: 94, frozen: 92 },
    { day: 'Sat', beverages: 95, snacks: 88, dairy: 96, frozen: 94 },
    { day: 'Sun', beverages: 78, snacks: 71, dairy: 83, frozen: 86 },
  ];

  return (
    <div className="h-80">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
          <XAxis 
            dataKey="day" 
            stroke="#9CA3AF"
            fontSize={12}
          />
          <YAxis 
            stroke="#9CA3AF"
            fontSize={12}
            label={{ value: 'Stock Level (%)', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#9CA3AF' } }}
          />
          <Legend />
          <Line 
            type="monotone" 
            dataKey="beverages" 
            stroke="#3B82F6" 
            strokeWidth={2}
            name="Beverages"
            dot={{ fill: '#3B82F6', strokeWidth: 2, r: 4 }}
          />
          <Line 
            type="monotone" 
            dataKey="snacks" 
            stroke="#10B981" 
            strokeWidth={2}
            name="Snacks"
            dot={{ fill: '#10B981', strokeWidth: 2, r: 4 }}
          />
          <Line 
            type="monotone" 
            dataKey="dairy" 
            stroke="#F59E0B" 
            strokeWidth={2}
            name="Dairy"
            dot={{ fill: '#F59E0B', strokeWidth: 2, r: 4 }}
          />
          <Line 
            type="monotone" 
            dataKey="frozen" 
            stroke="#EF4444" 
            strokeWidth={2}
            name="Frozen"
            dot={{ fill: '#EF4444', strokeWidth: 2, r: 4 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default StockLevelChart;