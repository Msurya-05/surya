import React from 'react';
import { DivideIcon as LucideIcon, TrendingUp, TrendingDown } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: LucideIcon;
  color: 'blue' | 'orange' | 'green' | 'purple';
}

const MetricCard: React.FC<MetricCardProps> = ({ 
  title, 
  value, 
  change, 
  trend, 
  icon: Icon,
  color 
}) => {
  const colorClasses = {
    blue: 'bg-blue-600 text-blue-100',
    orange: 'bg-orange-600 text-orange-100',
    green: 'bg-green-600 text-green-100',
    purple: 'bg-purple-600 text-purple-100'
  };

  const trendColor = trend === 'up' ? 'text-green-400' : 'text-red-400';
  const TrendIcon = trend === 'up' ? TrendingUp : TrendingDown;

  return (
    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700 hover:border-gray-600 transition-colors">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-gray-400 text-sm font-medium">{title}</p>
          <p className="text-2xl font-bold mt-1">{value}</p>
        </div>
        <div className={`p-3 rounded-lg ${colorClasses[color]}`}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
      <div className="flex items-center gap-1 mt-4">
        <TrendIcon className={`w-4 h-4 ${trendColor}`} />
        <span className={`text-sm font-medium ${trendColor}`}>{change}</span>
        <span className="text-gray-400 text-sm">vs last period</span>
      </div>
    </div>
  );
};

export default MetricCard;