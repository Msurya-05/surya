import React from 'react';
import { 
  LayoutDashboard, 
  Video, 
  Package, 
  TrendingUp, 
  AlertTriangle, 
  BarChart3,
  Brain,
  Eye
} from 'lucide-react';

type ActiveView = 'dashboard' | 'monitoring' | 'inventory' | 'forecasting' | 'alerts' | 'analytics';

interface SidebarProps {
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'monitoring', label: 'Live Monitoring', icon: Video },
    { id: 'inventory', label: 'Inventory', icon: Package },
    { id: 'forecasting', label: 'Demand Forecast', icon: TrendingUp },
    { id: 'alerts', label: 'Alerts Center', icon: AlertTriangle },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  ];

  return (
    <div className="w-64 bg-gray-800 border-r border-gray-700 flex flex-col">
      <div className="p-6 border-b border-gray-700">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <Brain className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold">AI Retail</h1>
            <p className="text-sm text-gray-400">Inventory System</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            
            return (
              <li key={item.id}>
                <button
                  onClick={() => setActiveView(item.id as ActiveView)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                    isActive 
                      ? 'bg-blue-600 text-white' 
                      : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="p-4 border-t border-gray-700">
        <div className="flex items-center gap-3 p-3 bg-gray-700 rounded-lg">
          <Eye className="w-8 h-8 text-green-400" />
          <div>
            <p className="text-sm font-medium">AI Vision Status</p>
            <p className="text-xs text-green-400">Active • 12 Cameras</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;