import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import LiveMonitoring from './components/LiveMonitoring';
import InventoryManagement from './components/InventoryManagement';
import Forecasting from './components/Forecasting';
import AlertsCenter from './components/AlertsCenter';
import Analytics from './components/Analytics';

type ActiveView = 'dashboard' | 'monitoring' | 'inventory' | 'forecasting' | 'alerts' | 'analytics';

function App() {
  const [activeView, setActiveView] = useState<ActiveView>('dashboard');

  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return <Dashboard />;
      case 'monitoring':
        return <LiveMonitoring />;
      case 'inventory':
        return <InventoryManagement />;
      case 'forecasting':
        return <Forecasting />;
      case 'alerts':
        return <AlertsCenter />;
      case 'analytics':
        return <Analytics />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white flex">
      <Sidebar activeView={activeView} setActiveView={setActiveView} />
      <main className="flex-1 overflow-y-auto">
        {renderContent()}
      </main>
    </div>
  );
}

export default App;